const server = require("./src/config/server");

require("./src/config/database");

server.listen(8000, () => {
    console.log("Server started")
})