const AuthMiddleware = require("./AuthMiddleware");

module.exports = {
    AuthMiddleware
};