const sendError = (msg, res) => {
    res.send({
        error: true,
        msg: msg,
        data: {}
    });
}

class AuthMiddleware {

    checkLoginBody(req, res, next) {
        if (!req.body.loginCredentials) {
            return sendError("loginCredentials is missing", res);
        }
        next();
    }

    checkSignUpBody(req, res, next) {
        if (!req.body.userName) {
            return sendError("UserName is required", res);
        }
        if (!req.body.email) {
            return sendError("Email is required", res);
        }
        if (!req.body.password) {
            return sendError("password is required", res);
        }
        next();
    }
}
module.exports = new AuthMiddleware();