const AuthController = require("./AuthController");

module.exports = {
    AuthController
}