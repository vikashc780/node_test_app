const { UserModel } = require("../models");
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');

const sendError = (msg, res) => {
    res.send({
        error: true,
        msg: msg,
        data: {}
    });
}

class AuthController {

    async login(req, res) {
        try {
            let user = await UserModel.findOne({
                $or: [
                    { email: req.body.loginCredentials },
                    { userName: req.body.loginCredentials }
                ]
            }).lean();
            if (!user) { return sendError("User not found", res); }
            const isValidPass = bcrypt.compareSync(req.body.password, user.password);
            if (!isValidPass) { return sendError("Incorrect password", res); }
            // Create token
            const token = jwt.sign(
                { userId: user._id },
                "test"
            );
            // save user token
            user.token = token;
            delete user.password;
            res.send({
                error: false,
                msg: "login successfully",
                data: user
            });
        } catch (error) {
            sendError(error.message, res);
        }
    }

    async signup(req, res) {
        try {
            const salt = bcrypt.genSaltSync(10);
            const hash = bcrypt.hashSync(req.body.password, salt);
            const data = {
                userName: req.body.userName,
                email: req.body.email,
                fullName: req.body.fullName,
                password: hash,
            };
            const user = await UserModel.create(data);
            res.send({
                error: false,
                msg: "Signup successfully",
                data: user
            });
        } catch (error) {
            sendError(error.message, res);
        }
    }


    async checkLogin(req, res) {
        try {
            if (!req.body.token)
                return sendError("Token is required", res);
            const token = jwt.verify(req.body.token, 'test');
            const user = await UserModel.findById(token.userId).lean()
            delete user.password;
            res.send({
                error: false,
                msg: "login successfully",
                data: user
            });
        } catch (error) {
            sendError(error.message, res)
        }
    }

}
module.exports = new AuthController();