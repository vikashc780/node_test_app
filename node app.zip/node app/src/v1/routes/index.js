const authRoutes = require("./authRoutes");

module.exports = {
    authRoutes
}