const express = require("express");
const { AuthController } = require("../controllers");
const { AuthMiddleware } = require("../middlewares");
const router = express.Router();

router.post("/login", AuthMiddleware.checkLoginBody, AuthController.login);
router.post("/sighup", AuthMiddleware.checkSignUpBody, AuthController.signup);
router.post("/checklogin", AuthController.checkLogin);

module.exports = router;