const UserModel = require("./User");
module.exports = {
    UserModel
}