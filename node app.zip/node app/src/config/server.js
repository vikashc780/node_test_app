const express = require("express");
const cors = require("cors");
const mapRoutes = require("./routes");
const server = express();
server.use(cors({
    origin: '*'
}));
server.use(express.json());

mapRoutes(server);

module.exports = server;