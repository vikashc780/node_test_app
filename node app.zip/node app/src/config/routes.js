const express = require("express");
const routes = require("../v1/routes");


const mapRoutes = server => {
    server.get("/", (req, res) => {
        res.send("Welcome to app!!!")
    });
    server.use("/auth", routes.authRoutes);
    
    server.use("*", (req, res) => {
        res.send("No route found");
    });
}

module.exports = mapRoutes;