const mongoose = require("mongoose");

class Connect {
    constructor() {
        const url = "mongodb://localhost:27017/test";
        this.connect(url).then(() => {
            console.log("Database connected successfully!!!")
        }).catch(e => {
            console.log('error will connecting database', e.message)
        })
    }

    async connect(url) {
        try {
            await mongoose.connect(url);
        } catch (error) {
            throw error
        }
    }
}

module.exports = new Connect();